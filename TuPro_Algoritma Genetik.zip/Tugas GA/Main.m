clear;
clc;

% Parameter GA
length_chrom = 7;
weight_capacity = 20;
population_size = 20;
mutation_rate = 0.2;
max_generations = 100;

% Inisialisasi populasi awal
chrom = create_chrom(population_size, length_chrom)
criteria = criteria(chrom, weight_capacity);
fitness = calculate_fitness(chrom, criteria);
population = create_population(chrom, fitness, population_size);

% Logging
fitness_history = zeros(max_generations, 1);
best_solution = struct('chrom', [], 'fitness', -Inf);

% Evolusi
for gen = 1:max_generations
    % Seleksi
    [parent1, parent2] = selection_roulette(population)
    
    % Crossover
    [child1, child2] = crossover(parent1, parent2);
    
    % Mutasi
    mutant1 = mutation(child1, mutation_rate);
    mutant2 = mutation(child2, mutation_rate);
    
    % Hitung fitness hasil mutasi
    mutant1.fitness = calculate_fitness(reshape(mutant1.chrom, 1, []), criteria);
    mutant2.fitness = calculate_fitness(reshape(mutant2.chrom, 1, []), criteria);
    
    % Regenerasi
    children = [mutant1, mutant2];
    population = regeneration(children, population);
    
    % Logging fitness terbaik
    current_fitness = [population.fitness];
    fitness_history(gen) = max(current_fitness);
    
    % Update solusi terbaik
    [max_fitness, idx] = max(current_fitness);
    if max_fitness > best_solution.fitness
        best_solution = population(idx);
    end
    
    % Tampilkan log
    fprintf('Generasi %d - Fitness terbaik: %d\n', gen, max_fitness);
    
    % Kondisi berhenti opsional (misal fitness mencapai target)
    if max_fitness >= 50 % <- ubah sesuai targetmu
        fprintf('Target fitness tercapai di generasi %d.\n', gen);
        break;
    end
end

% Finalisasi
fprintf('\n=== Solusi Terbaik ===\n');
fprintf('Kromosom terbaik: %s\n', mat2str(best_solution.chrom));
fprintf('Fitness terbaik: %d\n', best_solution.fitness);



