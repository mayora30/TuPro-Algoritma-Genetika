function population = create_population(chrom, fitness, population_size)    
    population = struct();
    for i = 1:population_size
        population(i).chrom = chrom(i, :);
        population(i).fitness = fitness(i);
    end
end