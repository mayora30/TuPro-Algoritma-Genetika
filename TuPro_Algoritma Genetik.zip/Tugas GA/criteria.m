function criteria = create_criteria(chrom, weight_capacity)
    % example dummy values
    value = [10 5 15 7 6 18 3];
    weight = [2 3 5 7 1 4 1];
    for i = 1:length(value)
        criteria(i).value = value(i);
        criteria(i).weight = weight(i);
    end
end

