function chrom = create_chrom(population_size, length_chrom)
    chrom = randi([0,1], population_size, length_chrom);
end