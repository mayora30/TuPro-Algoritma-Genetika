function mutant = mutation(child, mutation_rate)
    mutant = child;

    fprintf('Kromosom sebelum mutasi: %s\n', num2str(mutant.chrom));
    
    for i = 1:length(mutant.chrom)
        r = rand;
        fprintf('Bit ke-%d (sebelum): %d | rand = %.4f | ', ...
                i, mutant.chrom(i), r);
        
        if r <= mutation_rate
            mutant.chrom(i) = 1 - mutant.chrom(i);  % flip bit 0<->1
            fprintf('🧬 Mutasi jadi: %d\n', mutant.chrom(i));
        else
            fprintf('Tidak bermutasi.\n');
        end
    end

    fprintf('Kromosom setelah mutasi : %s\n\n', num2str(mutant.chrom));
end