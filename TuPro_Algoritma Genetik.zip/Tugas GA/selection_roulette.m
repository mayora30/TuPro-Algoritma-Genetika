function [parent1, parent2] = selection_roulette(population)
    % Ambil semua nilai fitness
    fitness_values = [population.fitness];
    
    % Normalisasi fitness menjadi probabilitas
    total_fitness = sum(fitness_values);
    if total_fitness == 0
        probabilities = ones(1, length(fitness_values)) / length(fitness_values);
    else
        probabilities = fitness_values / total_fitness;
    end

    % Roulette spin
    parent1 = population(roulette_wheel(probabilities));
    parent2 = population(roulette_wheel(probabilities));
end

function idx = roulette_wheel(probabilities)
    r = rand;
    cumulative = cumsum(probabilities);
    idx = find(r <= cumulative, 1, 'first');
end
