function new_population = regeneration(children, population)
    N = length(children);
    fitness = zeros(1, length(population));
    for i = 1:length(population)
        fitness(i) = population(i).fitness;
    end
    %sort fitness terkecil ke terbesar
        [~, sorted_index] = sort(fitness);
    %remove fitness terkecil
        population(sorted_index(1:N)) = [];
    %tambah anggota
    for i = 1:N
        population(end+1) = children(i);
    end
    new_population = population;
end
