function fitness = calculate_fitness(chrom, criteria)
    [row, ~] = size(chrom);
    fitness = zeros(row, 1);

    for i = 1:row
        selected = find(chrom(i, :) == 1);
        total_weight = sum([criteria(selected).weight]);
        total_value = sum([criteria(selected).value]);

        if total_weight <= 20  % constraint
            fitness(i) = total_value;
        else
            fitness(i) = 0; % penalize overweight solutions
        end
    end
end
